using Elder.Core.Common.BaseClasses;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace Elder.Unity.GameStep.Infrastructure
{
    public class UnitySceneGameStepExecutor : InfrastructureBase
    {
        public override void Initialize()
        {
            
        }
        protected override void DisposeManagedResources()
        {
            base.DisposeManagedResources();
        }
        protected override void DisposeUnmanagedResources()
        {

        }
    }
}
