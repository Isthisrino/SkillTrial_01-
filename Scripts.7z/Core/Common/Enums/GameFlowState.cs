namespace Elder.Core.Common.Enums
{
    public enum GameFlowState
    {
        None,
        Boot,
        Splash,
        Title,
        GamePlay,
    }
}
