namespace Elder.Core.Common.Enums
{
    public enum MainStepState
    {
        None,
        Boot,
        Splash,
        Title,
        GamePlay,
    }
}